# First-principles H0 (Theory+) — Minimal, Referee-proof Baseline

**One command:** `python environment_h0_bias.py`

- Uses `data/host_catalog.csv` (SH0ES-like: Cal higher-g, HF lower-g)
- Preserves **GR EM distances** (α_M=0) and **GW/EM = 1**
- Only allows small, conservative caps: **SN host ≤ 0.05 mag**, **Cepheid same-host ≤ 0.03 mag**
- Reports three points: Raw (SN-only), Cap (SN-only), Cap+Cepheid (default Cepheid=0)

Outputs: `outputs_paper_ready/{theoryplus_summary.csv, H0_points_theoryplus.png, invariants.json}`
